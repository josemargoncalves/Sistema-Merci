package br.com.sistemamerci.BO;

import br.com.sistemamerci.DAO.Usuario_has_GrupoUsuarioDAO;
import br.com.sistemamerci.entidade.UsuarioHasGrupoUsuario;
import java.util.List;

/**
 *
 * @author josemar
 */
public class UsuarioHasGrupoUsuarioBO {
    
    private Usuario_has_GrupoUsuarioDAO usuario_has_GrupoUsuarioDAO = new Usuario_has_GrupoUsuarioDAO();

    public void cadastrar(UsuarioHasGrupoUsuario usuario_has_GrupoUsuario) throws Exception{
        usuario_has_GrupoUsuarioDAO.cadastrar(usuario_has_GrupoUsuario);
    }
    
    public void excluir(int codigoUsuario) throws Exception{
        usuario_has_GrupoUsuarioDAO.deletar(codigoUsuario);
    }
    
    public UsuarioHasGrupoUsuario buscar(int codigoUsuario) throws Exception{
        return usuario_has_GrupoUsuarioDAO.buscar(codigoUsuario);
    }
    
    public List<UsuarioHasGrupoUsuario> listar() throws Exception{
        return usuario_has_GrupoUsuarioDAO.listar();
    }
}
