package br.com.sistemamerci.BO;

import br.com.sistemamerci.DAO.UsuarioDAO;
import br.com.sistemamerci.entidade.Usuario;
import br.com.sistemamerci.excecao.UsuarioNaoEncontradoException;

/**
 *
 * @author josemar
 */
public class UsuarioBO {
    
    UsuarioDAO usuarioDAO = new UsuarioDAO();
    
    public void atualizar(Usuario usuario) throws Exception{
        usuarioDAO.atualizar(usuario);
    }
    
    public Usuario buscarUsuarioPorLogin(String login) throws Exception{
        return usuarioDAO.buscarUsuarioPorLogin(login);
    }
    
    public Usuario buscarUsuarioPorCodigo(int codigo) throws Exception{
        return usuarioDAO.buscarUsuarioPorCodigo(codigo);
    }
    
    public void cadastrar(Usuario usuario) throws Exception{
        usuarioDAO.cadastrar(usuario);
    }
    
    public void excluir(String login) throws Exception{
        
        usuarioDAO.buscarUsuarioPorLogin(login);
        usuarioDAO.deletar(login);
    }
    
    public int getCodigoMax() throws Exception{
        return usuarioDAO.buscarMaxCodigo();
    }
}
