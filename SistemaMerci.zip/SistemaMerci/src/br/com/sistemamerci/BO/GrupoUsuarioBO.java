/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.sistemamerci.BO;

import br.com.sistemamerci.DAO.GrupoUsuarioDAO;
import br.com.sistemamerci.entidade.GrupoUsuario;

/**
 *
 * @author josemar
 */
public class GrupoUsuarioBO {
    
    GrupoUsuarioDAO grupoUsuarioDAO = new GrupoUsuarioDAO();
    
    public void cadastrar(GrupoUsuario grupoUsuario) throws Exception{
        this.grupoUsuarioDAO.cadastrar(grupoUsuario);
    }
    
    public void deletar(int codigo) throws Exception{
        this.grupoUsuarioDAO.deletar(codigo);
    }
    
    public void atualizar(GrupoUsuario grupoUsuario) throws Exception{
        this.grupoUsuarioDAO.atualizar(grupoUsuario);
    }
    
    public GrupoUsuario buscarPorCodigo(int codigo) throws Exception{
        return grupoUsuarioDAO.buscarGrupoUsuario(codigo);
    }
    public int getCodigoMax() throws Exception{
        return grupoUsuarioDAO.buscarMaxCodigo();
    }
}
