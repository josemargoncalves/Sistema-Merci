package br.com.sistemamerci.entidade;

/**
 *
 * @author josemar
 */
public class UsuarioHasGrupoUsuario {
    
    private int codigo,codigoGrupoUsuario,codigoUsuario;

    public void setCodigoUsuario(int codigoUsuario) {
        this.codigoUsuario = codigoUsuario;
    }

    public int getCodigoUsuario() {
        return codigoUsuario;
    }

    public int getCodigo() {
        return codigo;
    }

    public int getCodigoGrupoUsuario() {
        return codigoGrupoUsuario;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setCodigoGrupoUsuario(int codigoGrupoUsuario) {
        this.codigoGrupoUsuario = codigoGrupoUsuario;
    }

}
