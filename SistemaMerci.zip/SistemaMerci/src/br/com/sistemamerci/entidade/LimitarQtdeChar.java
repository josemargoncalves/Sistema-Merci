package br.com.sistemamerci.entidade;

import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

/**
 *
 * @author josemar
 */
public class LimitarQtdeChar extends PlainDocument{
    
    private final int qtdeMax;
    
    public LimitarQtdeChar(int qtdeMax){
        super();
        this.qtdeMax = qtdeMax;
    }
    
    @Override
    public void insertString(int offset, String str, javax.swing.text.AttributeSet attr) throws BadLocationException{
              
        if(str == null || getLength() == this.qtdeMax){
            return;
        }
        
        int total = (getLength() + str.length());
        
        if(total <= this.qtdeMax){
            super.insertString(offset, str.replaceAll("[^aA0-zZ9]", ""),attr);
        }else{
            super.insertString(offset, str.replaceAll("[^aA0-zZ9]", ""), attr);
        }
    }
}
