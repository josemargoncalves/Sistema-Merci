package br.com.sistemamerci.entidade;

/**
 *
 * @author josemar
 */
public class GrupoUsuario {
    private int codigo;
    private boolean gerente, gestorCompras,gestorEstoque,caixero;

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }

    public boolean isGestorCompras() {
        return gestorCompras;
    }

    public boolean isGerente() {
        return gerente;
    }

    public boolean isGestorEstoque() {
        return gestorEstoque;
    }

    public boolean isCaixero() {
        return caixero;
    }

    public void setGerente(boolean gerente) {
        this.gerente = gerente;
    }

    public void setGestorCompras(boolean getorCompras) {
        this.gestorCompras = getorCompras;
    }

    public void setGestorEstoque(boolean gestorEstoque) {
        this.gestorEstoque = gestorEstoque;
    }

    public void setCaixero(boolean caixero) {
        this.caixero = caixero;
    }
}
