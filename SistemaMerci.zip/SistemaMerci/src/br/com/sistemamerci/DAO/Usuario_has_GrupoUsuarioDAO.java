package br.com.sistemamerci.DAO;

import br.com.sistemamerci.entidade.Usuario;
import br.com.sistemamerci.entidade.UsuarioHasGrupoUsuario;
import br.com.sistemamerci.excecao.GrupoDeUsuarioNaoEncontradoException;
import br.com.sistemamerci.excecao.UsuarioNaoEncontradoException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author josemar
 */
public class Usuario_has_GrupoUsuarioDAO {
    
    private static final String SQL_SELECT = "SELECT * FROM USUARIO_HAS_GRUPO_USUARIO";
    private static final String SQL_SELECT_CODIGO_USUARIO = "SELECT * FROM USUARIO_HAS_GRUPO_USUARIO WHERE CODIGO_USUARIO_FK = ?;";
    private static final String SQL_INSERT = "INSERT INTO USUARIO_HAS_GRUPO_USUARIO(CODIGO_USUARIO_FK, GRUPO_USUARIO_FK) VALUES(?,?);";
    private static final String SQL_DELETE = "DELETE FROM USUARIO_HAS_GRUPO_USUARIO WHERE CODIGO_USUARIO_FK = ?";

    public void cadastrar(UsuarioHasGrupoUsuario usuarioGrupoUsuario) throws Exception{
        
        Connection conexao = null;
        PreparedStatement comando = null;
        
        try {
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_INSERT);
            
            comando.setInt(1, usuarioGrupoUsuario.getCodigoUsuario());
            comando.setInt(2, usuarioGrupoUsuario.getCodigoGrupoUsuario());

            comando.execute();
            
            conexao.commit();
            
        } catch (Exception e) {
            
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando);
        }
    }
     
    public void deletar(int codigoUsuario) throws SQLException, Exception{
     
        Connection conexao = null;
        PreparedStatement comando = null;
        
        try {
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_DELETE);
            
            comando.setInt(1, codigoUsuario);
            
            comando.execute();
            
            conexao.commit();            
    
        }catch(Exception e){
            
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando);
        }    
    }
     
    public UsuarioHasGrupoUsuario buscar(int codigoUsuario) throws SQLException, Exception{
        
        UsuarioHasGrupoUsuario usuarioGrupoUsuario = null;
        Connection conexao = null;
        PreparedStatement comando = null;
        ResultSet resultado = null;
        
        try {
            
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_SELECT_CODIGO_USUARIO);
            
            comando.setInt(1, codigoUsuario);
            
            resultado = comando.executeQuery();
            
            if(resultado.next())   
                usuarioGrupoUsuario = this.extrairLinha(resultado);
            else throw new UsuarioNaoEncontradoException();
            
            conexao.commit();
            
        } catch (Exception e) {
        
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando, resultado);
        }
        
        return usuarioGrupoUsuario;
    }

    public List<UsuarioHasGrupoUsuario> listar() throws SQLException, Exception{
        
        List<UsuarioHasGrupoUsuario> listUsuarioGrupoUsuario = new ArrayList<>();
        Connection conexao = null;
        PreparedStatement comando = null;
        ResultSet resultado = null;
        
        try {
            
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_SELECT);
        
            resultado = comando.executeQuery();
            
            while(resultado.next()){  
                UsuarioHasGrupoUsuario usuarioHasGrupoUsuario;
                
                usuarioHasGrupoUsuario = this.extrairLinha(resultado);
                
                listUsuarioGrupoUsuario.add(usuarioHasGrupoUsuario);
            }
            
            conexao.commit();
            
        } catch (Exception e) {
        
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando, resultado);
        }
        
        return listUsuarioGrupoUsuario;
    }
    
    private UsuarioHasGrupoUsuario extrairLinha(ResultSet resultado) throws SQLException{
        
        UsuarioHasGrupoUsuario usuarioGrupoUsuario = new UsuarioHasGrupoUsuario();
              
        usuarioGrupoUsuario.setCodigo(resultado.getInt(1));
        usuarioGrupoUsuario.setCodigoUsuario(resultado.getInt(2));
        usuarioGrupoUsuario.setCodigoGrupoUsuario(resultado.getInt(3));
        
        return usuarioGrupoUsuario;
    }
}
