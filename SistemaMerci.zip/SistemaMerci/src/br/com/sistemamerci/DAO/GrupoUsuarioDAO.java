package br.com.sistemamerci.DAO;

import br.com.sistemamerci.entidade.GrupoUsuario;
import br.com.sistemamerci.entidade.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author josemar
 */
public class GrupoUsuarioDAO {
    
    private static final String SQL_SELECT_CODIGO = "SELECT * FROM GRUPO_USUARIO WHERE CODIGO = ?;";
    private static final String SQL_INSERT = "INSERT INTO GRUPO_USUARIO(GERENTE, GESTOR_COMPRAS, GESTOR_ESTOQUE, CAIXEIRO) VALUES(?,?,?,?);";
    private static final String SQL_DELETE = "DELETE FROM GRUPO_USUARIO WHERE CODIGO = ?";
    private static final String SQL_UPDATE = "UPDATE GRUPO_USUARIO SET GERENTE = ?, GESTOR_COMPRAS = ?, GESTOR_ESTOQUE = ?, CAIXEIRO = ? WHERE CODIGO = ?";
    private static final String SQL_MAX_CODIGO = "SELECT MAX(CODIGO) FROM GRUPO_USUARIO";
    
    public void cadastrar(GrupoUsuario grupoUsuario) throws Exception{
        
        Connection conexao = null;
        PreparedStatement comando = null;
        
        try {
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_INSERT);
            
            comando.setBoolean(1, grupoUsuario.isGerente());
            comando.setBoolean(2, grupoUsuario.isGestorCompras());
            comando.setBoolean(3, grupoUsuario.isGestorEstoque());
            comando.setBoolean(4, grupoUsuario.isCaixero());

            comando.execute();
            
            conexao.commit();
            
        } catch (Exception e) {
            
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando);
        }
    }
    
    public void atualizar(GrupoUsuario grupoUsuario) throws SQLException, Exception{
        
        Connection conexao = null;
        PreparedStatement comando = null;
        
        try {
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_UPDATE);
            
            comando.setBoolean(1, grupoUsuario.isGerente());
            comando.setBoolean(2, grupoUsuario.isGestorCompras());
            comando.setBoolean(3, grupoUsuario.isGestorEstoque());
            comando.setBoolean(4, grupoUsuario.isCaixero());
            comando.setInt(5, grupoUsuario.getCodigo());
            
            comando.execute();
            
            conexao.commit();
            
        } catch (Exception e) {
            
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando);
        }
    }
    
    public void deletar(int codigoGrupoUsuario) throws SQLException, Exception{
     
        Connection conexao = null;
        PreparedStatement comando = null;
        
        try {
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_DELETE);
            
            comando.setInt(1, codigoGrupoUsuario);
            
            comando.execute();
            
            conexao.commit();
            
        }catch(Exception e){
            
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando);
        }    
    }
    
    public GrupoUsuario buscarGrupoUsuario(int codigo) throws SQLException, Exception{
        
        GrupoUsuario grupoUsuario = null;
        Connection conexao = null;
        PreparedStatement comando = null;
        ResultSet resultado = null;
        
        try {
            
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_SELECT_CODIGO);
            
            comando.setInt(1, codigo);
            
            resultado = comando.executeQuery();
            
            if(resultado.next())   
                grupoUsuario = this.extrairLinha(resultado);
            
            conexao.commit();
            
        } catch (Exception e) {
        
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando, resultado);
        }
        
        return grupoUsuario;
    }
    
    
    public int buscarMaxCodigo() throws SQLException, Exception{
        
        int codigoMax = 0;
        Connection conexao = null;
        PreparedStatement comando = null;
        ResultSet resultado = null;
        
        try {
            
            conexao = Conexao.getConexao();
            
            comando = conexao.prepareStatement(SQL_MAX_CODIGO);
            
            
            resultado = comando.executeQuery();
            
            if(resultado.next())   
                codigoMax = resultado.getInt(1);
            
            conexao.commit();
            
        } catch (Exception e) {
        
            if(conexao != null)
                conexao.rollback();
            throw e;
            
        }finally{
            Conexao.fecharConexoes(conexao, comando, resultado);
        }
        
        return codigoMax;
    }
    
    private GrupoUsuario extrairLinha(ResultSet resultado) throws SQLException{
        
        GrupoUsuario grupoUsuario = new GrupoUsuario();
        
        grupoUsuario.setCodigo(resultado.getInt(1));
        grupoUsuario.setGerente(resultado.getBoolean(2));
        grupoUsuario.setGestorCompras(resultado.getBoolean(3));
        grupoUsuario.setGestorEstoque(resultado.getBoolean(4));
        grupoUsuario.setCaixero(resultado.getBoolean(5));
        
        return grupoUsuario;
    }
}
