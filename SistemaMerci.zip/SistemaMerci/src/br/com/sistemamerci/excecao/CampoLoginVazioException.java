package br.com.sistemamerci.excecao;

/**
 *
 * @author josemar
 */
public class CampoLoginVazioException extends SistemaMerciException{

    public CampoLoginVazioException() {
        super("Erro!!! O campo login não foi especificado para realizar a operação");
    }
    
}
