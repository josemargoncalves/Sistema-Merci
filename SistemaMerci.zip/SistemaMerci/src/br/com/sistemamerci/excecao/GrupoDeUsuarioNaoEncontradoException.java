package br.com.sistemamerci.excecao;

/**
 *
 * @author josemar
 */
public class GrupoDeUsuarioNaoEncontradoException extends SistemaMerciException{

    public GrupoDeUsuarioNaoEncontradoException() {
        super("Grupo de Usuario não encontrado");
    }
    
}
