package br.com.sistemamerci.excecao;

/**
 *
 * @author josemar
 */
public class SistemaMerciException extends RuntimeException{

    public SistemaMerciException(String message) {
        super(message);
    }
    
    public static String messageErro() {
        return "Erro! não foi possível realizar a operação!";
    }
}
