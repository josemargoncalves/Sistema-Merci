package br.com.sistemamerci.excecao;

/**
 *
 * @author josemar
 */
public class UsuarioNaoEncontradoException extends SistemaMerciException{

    public UsuarioNaoEncontradoException() {
        super("Usuário não encontrado");
    }
}
