package br.com.sistemamerci.excecao;

/**
 *
 * @author josemar
 */
public class SenhaIncorretaException extends SistemaMerciException{

    public SenhaIncorretaException() {
        super("Erro!!! Senha incorreta");
    }
    
}
