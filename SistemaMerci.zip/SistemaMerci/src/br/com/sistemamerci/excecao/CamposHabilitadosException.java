package br.com.sistemamerci.excecao;

/**
 *
 * @author josemar
 */
public class CamposHabilitadosException extends SistemaMerciException{

    public CamposHabilitadosException() {
        super("Erro!!! Todos os campos de textos habilitados devem devem ser preenchidos");
    }
}
