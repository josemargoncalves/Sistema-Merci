package br.com.sistemamerci.excecao;

/**
 *
 * @author josemar
 */
public class SenhasDiferentesException extends SistemaMerciException{

    public SenhasDiferentesException() {
        super("Erro!!! O campo de senha e o campo de confirmar senha são diferentes");
    }
    
}
